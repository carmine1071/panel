<?php


header("Location: ../stop.php");

?>