<?php
?>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</div>

<!-- Footer -->
<footer class="sticky-footer">
    <center></center>
    <div class="container">
        <div class="copyright text-center">
            <span><a href="" target="_blank">&#169; PRIMETIME IBO <sup>Panel Manager</sup></a></span>
        </div>
    </div>
</footer>
<!-- End of Footer -->

